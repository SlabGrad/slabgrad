SlabGrad Core v2.1.0-beta.1

Upgrade package for the existing SlabGrad Core WordPress plugin.

Key changes:
- Card Identity Engine v2
- token-based player/character matching
- adaptive matching thresholds
- sports-card brand and set recognition
- grader and grade validation
- variant, language, parallel, lot, proxy, and reprint filtering
- up to 200 active eBay results per search
- parser diagnostics endpoint: /wp-json/slabgrad/v1/market/parse
- detailed diagnostics in market-search responses
- retained portfolio, snapshots, feedback, and eBay settings

Important: Market estimates use current eBay active listing asking prices. They are not completed sales, accepted Best Offer amounts, or appraisals.


V2.1 fixes strict grader/grade isolation. Searches specifying PSA 9 now exclude PSA 10, other grades, and listings whose grade cannot be confirmed from the title.
