<?php
/**
 * Plugin Name: SlabGrad Core
 * Description: SlabGrad beta backend for live eBay market search, comparable filtering, valuation snapshots, portfolios, and site integration.
 * Version: 2.1.0-beta.1
 * Author: SlabGrad
 * Requires PHP: 8.0
 */
if (!defined('ABSPATH')) exit;

final class SlabGrad_Core {
 const VER='2.1.0-beta.1';
 const NS='slabgrad/v1';

 public static function init(){
  register_activation_hook(__FILE__,[__CLASS__,'activate']);
  add_action('plugins_loaded',[__CLASS__,'maybe_upgrade']);
  add_action('rest_api_init',[__CLASS__,'routes']);
  add_action('admin_menu',[__CLASS__,'menu']);
  add_action('admin_init',[__CLASS__,'settings']);
  add_action('admin_post_sg_clear_cache',[__CLASS__,'clear_cache']);
  add_action('wp_enqueue_scripts',[__CLASS__,'assets'],20);
 }

 static function tables(){global $wpdb;return ['portfolio'=>$wpdb->prefix.'sg_portfolio','snapshots'=>$wpdb->prefix.'sg_market_snapshots','feedback'=>$wpdb->prefix.'sg_feedback'];}
 static function maybe_upgrade(){if(get_option('sg_core_db_version')!==self::VER) self::activate();}
 static function activate(){
  global $wpdb;$t=self::tables();$c=$wpdb->get_charset_collate();require_once ABSPATH.'wp-admin/includes/upgrade.php';
  dbDelta("CREATE TABLE {$t['portfolio']} (id bigint unsigned NOT NULL AUTO_INCREMENT,user_id bigint unsigned NOT NULL,card_key varchar(190) DEFAULT '',card_name varchar(190) NOT NULL,card_set varchar(190) DEFAULT '',card_number varchar(60) DEFAULT '',year varchar(10) DEFAULT '',category varchar(60) DEFAULT '',variant varchar(80) DEFAULT '',language varchar(40) DEFAULT 'English',grader varchar(20) DEFAULT '',grade varchar(20) DEFAULT '',cert_number varchar(100) DEFAULT '',quantity int unsigned DEFAULT 1,cost decimal(12,2) DEFAULT 0,market_value decimal(12,2) DEFAULT 0,notes text,created_at datetime NOT NULL,updated_at datetime NOT NULL,PRIMARY KEY(id),KEY user_id(user_id),KEY card_key(card_key)) $c;");
  dbDelta("CREATE TABLE {$t['snapshots']} (id bigint unsigned NOT NULL AUTO_INCREMENT,card_key varchar(190) DEFAULT '',query_hash char(64) NOT NULL,query_text varchar(255) NOT NULL,estimate_type varchar(40) DEFAULT 'active_listing',median_price decimal(12,2) DEFAULT 0,low_price decimal(12,2) DEFAULT 0,high_price decimal(12,2) DEFAULT 0,listing_count int DEFAULT 0,excluded_count int DEFAULT 0,confidence int DEFAULT 0,payload longtext,created_at datetime NOT NULL,PRIMARY KEY(id),KEY card_key(card_key),KEY query_hash(query_hash),KEY created_at(created_at)) $c;");
  dbDelta("CREATE TABLE {$t['feedback']} (id bigint unsigned NOT NULL AUTO_INCREMENT,user_id bigint unsigned DEFAULT 0,email varchar(190) DEFAULT '',type varchar(40) DEFAULT 'general',message text NOT NULL,page_url text,created_at datetime NOT NULL,PRIMARY KEY(id)) $c;");
  update_option('sg_core_db_version',self::VER);
 }

 static function assets(){
  wp_enqueue_script('slabgrad-core',plugins_url('assets/slabgrad-core.js',__FILE__),[],self::VER,true);
  wp_localize_script('slabgrad-core','SlabGradCore',['root'=>esc_url_raw(rest_url(self::NS.'/')),'nonce'=>wp_create_nonce('wp_rest'),'loggedIn'=>is_user_logged_in(),'loginUrl'=>wp_login_url(get_permalink()),'version'=>self::VER]);
 }
 static function menu(){add_menu_page('SlabGrad Core','SlabGrad Core','manage_options','slabgrad-core',[__CLASS__,'admin'],'dashicons-chart-line',58);}
 static function settings(){
  register_setting('sg_core','sg_ebay_client_id',['sanitize_callback'=>'sanitize_text_field']);
  register_setting('sg_core','sg_ebay_client_secret',['sanitize_callback'=>'sanitize_text_field']);
  register_setting('sg_core','sg_ebay_marketplace',['sanitize_callback'=>'sanitize_text_field','default'=>'EBAY_US']);
  register_setting('sg_core','sg_search_cache_minutes',['sanitize_callback'=>fn($v)=>max(1,min(1440,(int)$v)),'default'=>15]);
  register_setting('sg_core','sg_min_match_score',['sanitize_callback'=>fn($v)=>max(40,min(100,(int)$v)),'default'=>60]);
 }
 static function admin(){
  if(!current_user_can('manage_options'))return;
  $configured=(bool)(get_option('sg_ebay_client_id')&&get_option('sg_ebay_client_secret'));
  $health=rest_url(self::NS.'/health');
  ?>
  <div class="wrap"><h1>SlabGrad Core <small style="font-size:14px">v<?php echo esc_html(self::VER);?></small></h1>
   <p><strong>Status:</strong> <?php echo $configured?'<span style="color:#138a42">Production credentials configured</span>':'<span style="color:#b32d2e">Credentials required</span>';?></p>
   <form method="post" action="options.php"><?php settings_fields('sg_core');?>
    <table class="form-table">
     <tr><th>eBay Client ID</th><td><input class="regular-text" name="sg_ebay_client_id" value="<?php echo esc_attr(get_option('sg_ebay_client_id'));?>" autocomplete="off"></td></tr>
     <tr><th>eBay Client Secret</th><td><input class="regular-text" type="password" name="sg_ebay_client_secret" value="<?php echo esc_attr(get_option('sg_ebay_client_secret'));?>" autocomplete="new-password"></td></tr>
     <tr><th>Marketplace</th><td><select name="sg_ebay_marketplace"><option value="EBAY_US" <?php selected(get_option('sg_ebay_marketplace','EBAY_US'),'EBAY_US');?>>eBay US</option></select></td></tr>
     <tr><th>Search cache</th><td><input type="number" min="1" max="1440" name="sg_search_cache_minutes" value="<?php echo esc_attr(get_option('sg_search_cache_minutes',15));?>"> minutes</td></tr>
     <tr><th>Minimum match score</th><td><input type="number" min="40" max="100" name="sg_min_match_score" value="<?php echo esc_attr(get_option('sg_min_match_score',60));?>">%</td></tr>
    </table><?php submit_button('Save Settings');?></form>
   <p><button type="button" class="button button-primary" id="sg-test-connection">Test Production Connection</button> <span id="sg-test-result"></span></p>
   <form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>" style="margin-top:12px"><input type="hidden" name="action" value="sg_clear_cache"><?php wp_nonce_field('sg_clear_cache');?><button class="button">Clear SlabGrad Cache</button></form>
   <hr><h2>Installed beta capabilities</h2><p>Live eBay active-listing search, Card Identity Engine v2.1, strict grader/grade matching, adaptive comparable matching, outlier-resistant asking-price estimates, confidence scoring, diagnostics, market snapshots, history endpoint, Vault records, and beta feedback.</p>
   <p><strong>Data notice:</strong> eBay Browse API results are current active listings and asking prices. They are not completed-sale records, accepted Best Offer amounts, or appraisals.</p>
   <p><code><?php echo esc_html($health);?></code></p>
  </div>
  <script>document.getElementById('sg-test-connection')?.addEventListener('click',async function(){const out=document.getElementById('sg-test-result');this.disabled=true;out.textContent='Testing…';try{const r=await fetch('<?php echo esc_js(rest_url(self::NS.'/ebay/test'));?>',{headers:{'X-WP-Nonce':'<?php echo esc_js(wp_create_nonce('wp_rest'));?>'}});const j=await r.json();out.textContent=r.ok?'Connected: '+j.marketplace+' · '+j.result_count+' sample results':'Failed: '+(j.message||'Unknown error');out.style.color=r.ok?'#138a42':'#b32d2e';}catch(e){out.textContent='Failed: '+e.message;out.style.color='#b32d2e';}finally{this.disabled=false;}});</script>
  <?php
 }
 static function clear_cache(){if(!current_user_can('manage_options')||!check_admin_referer('sg_clear_cache'))wp_die('Not allowed');global $wpdb;$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_sg_%' OR option_name LIKE '_transient_timeout_sg_%'");wp_safe_redirect(admin_url('admin.php?page=slabgrad-core&cache=cleared'));exit;}

 static function routes(){
  register_rest_route(self::NS,'/health',['methods'=>'GET','callback'=>[__CLASS__,'health'],'permission_callback'=>'__return_true']);
  register_rest_route(self::NS,'/ebay/test',['methods'=>'GET','callback'=>[__CLASS__,'test_ebay'],'permission_callback'=>fn()=>current_user_can('manage_options')]);
  register_rest_route(self::NS,'/market/search',['methods'=>['GET','POST'],'callback'=>[__CLASS__,'search'],'permission_callback'=>'__return_true']);
  register_rest_route(self::NS,'/market/parse',['methods'=>['GET','POST'],'callback'=>[__CLASS__,'parse_endpoint'],'permission_callback'=>'__return_true']);
  register_rest_route(self::NS,'/market/history',['methods'=>'GET','callback'=>[__CLASS__,'history'],'permission_callback'=>'__return_true']);
  register_rest_route(self::NS,'/portfolio',['methods'=>'GET','callback'=>[__CLASS__,'portfolio_get'],'permission_callback'=>fn()=>is_user_logged_in()]);
  register_rest_route(self::NS,'/portfolio',['methods'=>'POST','callback'=>[__CLASS__,'portfolio_add'],'permission_callback'=>fn()=>is_user_logged_in()]);
  register_rest_route(self::NS,'/portfolio/(?P<id>\d+)',['methods'=>['PUT','PATCH'],'callback'=>[__CLASS__,'portfolio_update'],'permission_callback'=>fn()=>is_user_logged_in()]);
  register_rest_route(self::NS,'/portfolio/(?P<id>\d+)',['methods'=>'DELETE','callback'=>[__CLASS__,'portfolio_delete'],'permission_callback'=>fn()=>is_user_logged_in()]);
  register_rest_route(self::NS,'/feedback',['methods'=>'POST','callback'=>[__CLASS__,'feedback'],'permission_callback'=>'__return_true']);
 }
 static function health(){global $wpdb;$t=self::tables();return ['ok'=>true,'version'=>self::VER,'ebay_configured'=>(bool)(get_option('sg_ebay_client_id')&&get_option('sg_ebay_client_secret')),'marketplace'=>get_option('sg_ebay_marketplace','EBAY_US'),'database'=>['portfolio'=>$wpdb->get_var("SHOW TABLES LIKE '{$t['portfolio']}'")===$t['portfolio'],'snapshots'=>$wpdb->get_var("SHOW TABLES LIKE '{$t['snapshots']}'")===$t['snapshots']]];}

 static function token($force=false){
  $id=trim((string)get_option('sg_ebay_client_id'));$sec=trim((string)get_option('sg_ebay_client_secret'));
  if(!$id||!$sec)return new WP_Error('not_configured','eBay credentials are not configured.',['status'=>503]);
  if(!$force&&($cached=get_transient('sg_ebay_token')))return $cached;
  $r=wp_remote_post('https://api.ebay.com/identity/v1/oauth2/token',['timeout'=>25,'headers'=>['Authorization'=>'Basic '.base64_encode($id.':'.$sec),'Content-Type'=>'application/x-www-form-urlencoded'],'body'=>http_build_query(['grant_type'=>'client_credentials','scope'=>'https://api.ebay.com/oauth/api_scope'],'','&')]);
  if(is_wp_error($r))return new WP_Error('ebay_network',$r->get_error_message(),['status'=>502]);
  $code=wp_remote_retrieve_response_code($r);$b=json_decode(wp_remote_retrieve_body($r),true);
  if($code>=400||empty($b['access_token']))return new WP_Error('ebay_auth',$b['error_description']??'Unable to authenticate with eBay production.',['status'=>502,'ebay_status'=>$code]);
  set_transient('sg_ebay_token',$b['access_token'],max(300,((int)($b['expires_in']??7200))-120));return $b['access_token'];
 }
 static function test_ebay(){delete_transient('sg_ebay_token');$token=self::token(true);if(is_wp_error($token))return $token;$r=self::ebay_request('PSA graded card',$token,3);if(is_wp_error($r))return $r;return ['connected'=>true,'marketplace'=>get_option('sg_ebay_marketplace','EBAY_US'),'result_count'=>count($r['itemSummaries']??[]),'timestamp'=>gmdate('c')];}
 static function ebay_request($query,$token,$limit=100){
  $url=add_query_arg(['q'=>$query,'limit'=>min(200,max(1,(int)$limit)),'filter'=>'buyingOptions:{FIXED_PRICE|AUCTION}'],'https://api.ebay.com/buy/browse/v1/item_summary/search');
  $r=wp_remote_get($url,['timeout'=>30,'headers'=>['Authorization'=>'Bearer '.$token,'X-EBAY-C-MARKETPLACE-ID'=>get_option('sg_ebay_marketplace','EBAY_US'),'Accept'=>'application/json']]);
  if(is_wp_error($r))return new WP_Error('ebay_network',$r->get_error_message(),['status'=>502]);
  $code=wp_remote_retrieve_response_code($r);$body=json_decode(wp_remote_retrieve_body($r),true);
  if($code===401){delete_transient('sg_ebay_token');return new WP_Error('ebay_auth','eBay rejected the production token. Re-save the production keys and test again.',['status'=>502]);}
  if($code>=400)return new WP_Error('ebay_search',$body['errors'][0]['message']??'eBay search failed.',['status'=>502,'ebay_status'=>$code]);return is_array($body)?$body:[];
 }

 static function request_query(WP_REST_Request $r){$p=$r->get_json_params();return trim((string)($p['query']??$p['q']??$r->get_param('q')??$r->get_param('query')??''));}
 static function parse_card($q){
  $raw=trim((string)$q);$l=self::norm($raw);
  $data=['year'=>'','category'=>'','brand'=>'','set'=>'','subject'=>'','subject_tokens'=>[],'card_number'=>'','grader'=>'','grade'=>'','variant'=>'','parallel'=>'','language'=>'English','query_tokens'=>[]];
  if(preg_match('/\\b(18|19|20)\\d{2}(?:-\\d{2})?\\b/',$raw,$m))$data['year']=$m[0];
  if(preg_match('/\\b(psa|bgs|beckett|cgc|sgc|tag|hga|ace)\\b/i',$raw,$m)){$g=strtoupper($m[1]);$data['grader']=$g==='BECKETT'?'BGS':$g;}
  if($data['grader']&&preg_match('/\\b(?:psa|bgs|beckett|cgc|sgc|tag|hga|ace)\\s*(?:gem\\s*mint\\s*)?(10|9\\.5|9|8\\.5|8|7\\.5|7|6|5|4|3|2|1)\\b/i',$raw,$m))$data['grade']=$m[1];
  elseif(preg_match('/\\b(?:grade|gem\\s*mint|mint)\\s*(10|9\\.5|9|8\\.5|8|7\\.5|7|6|5|4|3|2|1)\\b/i',$raw,$m))$data['grade']=$m[1];
  if(preg_match('/(?:#|no\\.?\\s*)?(\\d{1,4}\\s*\\/\\s*\\d{1,4})\\b/i',$raw,$m))$data['card_number']=preg_replace('/\\s+/','',$m[1]);
  elseif(preg_match('/\\B#\\s*([a-z]{0,4}\\d{1,4}[a-z]{0,4})\\b/i',$raw,$m))$data['card_number']=strtoupper($m[1]);

  if(str_contains($l,'pokemon')||str_contains($l,'pokémon'))$data['category']='Pokemon';
  elseif(str_contains($l,'magic the gathering')||preg_match('/\\bmtg\\b/i',$raw))$data['category']='Magic';
  elseif(str_contains($l,'one piece'))$data['category']='One Piece';
  elseif(str_contains($l,'yu gi oh')||str_contains($l,'yugioh'))$data['category']='Yu-Gi-Oh!';
  elseif(preg_match('/\\b(baseball|basketball|football|hockey|soccer|wrestling|golf|racing)\\b/i',$raw,$m))$data['category']=ucfirst(strtolower($m[1]));

  $brands=['panini','donruss','topps','bowman','upper deck','fleer','score','leaf','select','prizm','optic','mosaic','chronicles','national treasures','flawless','immaculate','pokemon','wizards of the coast'];
  foreach($brands as $brand)if(str_contains($l,$brand)){$data['brand']=ucwords($brand);break;}
  $sets=['base set','team rocket','jungle','fossil','neo genesis','evolutions','celebrations','crown zenith','silver tempest','lost origin','fusion strike','evolving skies','scarlet violet','paldea evolved','obsidian flames','151','donruss optic','donruss','prizm','select','mosaic','national treasures','flawless','immaculate','topps chrome','bowman chrome'];
  foreach($sets as $set)if(preg_match('/\\b'.preg_quote($set,'/').'\\b/i',$raw)){$data['set']=ucwords($set);break;}

  if(str_contains($l,'1st edition')||str_contains($l,'first edition'))$data['variant']='1st Edition';
  elseif(str_contains($l,'shadowless'))$data['variant']='Shadowless';
  elseif(str_contains($l,'unlimited'))$data['variant']='Unlimited';
  elseif(str_contains($l,'rookie')||preg_match('/\\brc\\b/i',$raw))$data['variant']='Rookie';

  $parallels=['silver','holo','holofoil','refractor','xfractor','gold','red','blue','green','purple','orange','pink','black','white','wave','ice','laser','checkerboard','genesis','downtown','kaboom','cracked ice','hyper','scope'];
  foreach($parallels as $parallel)if(preg_match('/\\b'.preg_quote($parallel,'/').'\\b/i',$raw)){$data['parallel']=ucwords($parallel);break;}

  if(preg_match('/\\b(japanese|japan|jp)\\b/i',$raw))$data['language']='Japanese';
  elseif(preg_match('/\\b(spanish|french|german|italian|korean|chinese)\\b/i',$raw,$m))$data['language']=ucfirst(strtolower($m[1]));

  $stop=['pokemon','pokémon','basketball','baseball','football','hockey','soccer','wrestling','golf','racing','magic','gathering','mtg','one','piece','yugioh','yu','gi','oh','panini','donruss','topps','bowman','upper','deck','fleer','score','leaf','select','prizm','optic','mosaic','chronicles','national','treasures','flawless','immaculate','base','set','team','rocket','jungle','fossil','neo','genesis','evolutions','celebrations','crown','zenith','silver','tempest','lost','origin','fusion','strike','evolving','skies','scarlet','violet','paldea','evolved','obsidian','flames','psa','bgs','beckett','cgc','sgc','tag','hga','ace','gem','mint','grade','first','edition','1st','shadowless','unlimited','rookie','rc','english','japanese','spanish','french','german','italian','korean','chinese'];
  foreach($parallels as $x)$stop=array_merge($stop,explode(' ',$x));
  $tokens=preg_split('/[^a-z0-9]+/i',remove_accents($raw));$subject=[];
  foreach($tokens as $x){$xl=strtolower($x);if(!$x||strlen($x)<2||in_array($xl,$stop,true)||preg_match('/^\\d+(?:\\.\\d+)?(?:-\\d+)?$/',$x)||$x===$data['year'])continue;if($data['card_number']&&strtolower(str_replace('/','',$data['card_number']))===strtolower(str_replace('/','',$x)))continue;$subject[]=$x;}
  $subject=array_values(array_unique($subject));if(count($subject)>5)$subject=array_slice($subject,0,5);
  $data['subject_tokens']=array_map('strtolower',$subject);$data['subject']=implode(' ',$subject);
  $data['query_tokens']=array_values(array_unique(array_filter(explode(' ',self::norm($raw)),fn($x)=>strlen($x)>1)));
  $parts=[$data['category'],$data['year'],$data['brand'],$data['set'],$data['card_number'],$data['subject'],$data['language'],$data['variant'],$data['parallel'],$data['grader'].$data['grade']];
  $data['card_key']=preg_replace('/[^A-Z0-9]+/','-',strtoupper(implode('-',array_filter($parts))));
  return $data;
 }
 static function norm($s){$s=strtolower(remove_accents((string)$s));$s=preg_replace('/[^a-z0-9.\/]+/',' ',$s);return trim(preg_replace('/\s+/',' ',$s));}
 static function listing_grade($title){
  // Recognize common slab-title forms: PSA 9, PSA MINT 9, PSA GEM MT 10,
  // PSA NM-MT 8, BGS 9.5, CGC PRISTINE 10, and similar variations.
  $grader='(?:psa|bgs|beckett|cgc|sgc|tag|hga|ace)';
  $descriptor='(?:(?:gem\s*(?:mint|mt)|mint|nm[\s-]*mt|near\s*mint|pristine|perfect|excellent|ex[\s-]*mt)\s*)?';
  if(preg_match('/\b'.$grader.'\s*'.$descriptor.'(10|9\.5|9|8\.5|8|7\.5|7|6|5|4|3|2|1)\b/i',$title,$m))return $m[1];
  return '';
 }
 static function listing_grader($title){
  if(preg_match('/\\b(psa|bgs|beckett|cgc|sgc|tag|hga|ace)\\b/i',$title,$m))return strtoupper($m[1])==='BECKETT'?'BGS':strtoupper($m[1]);
  return '';
 }
 static function score_listing($title,$card,$query){
  $t=self::norm($title);$score=0;$reasons=[];$penalties=[];$excluded='';
  $hard=['proxy','reprint','custom card','digital card','case only','empty box','replica','facsimile','orica','metal card','print only','photo only'];
  foreach($hard as $bad)if(str_contains($t,$bad))return [0,['excluded: '.$bad],$bad,[]];
  if(preg_match('/\\b(lot of|lot\\s+\\d+|\\d+\\s+card lot|bundle|collection of|complete set)\\b/',$t))return [0,['excluded: multi-card lot'],'multi-card lot',[]];

  $listing_grader=self::listing_grader($title);$listing_grade=self::listing_grade($title);
  $required_grader=(string)($card['grader']??'');$required_grade=(string)($card['grade']??'');

  // A requested slab grade is part of the card identity, not a soft keyword.
  // Never mix PSA 9 with PSA 10, and never allow an unconfirmed grade into
  // a graded-card valuation when both grader and grade were supplied.
  if($required_grader&&$listing_grader!==$required_grader){
   return [0,['excluded: wrong or missing grader'],$listing_grader?'wrong grader':'grader missing',[]];
  }
  if($required_grade&&$listing_grade!==$required_grade){
   return [0,['excluded: wrong or missing grade'],$listing_grade?'wrong grade':'grade missing',[]];
  }
  if($required_grader){$score+=18;$reasons[]='exact grader match';}
  elseif($listing_grader){$score+=2;$reasons[]='graded listing';}
  if($required_grade){$score+=18;$reasons[]='exact grade match';}

  if(($card['year']??'')&&preg_match('/\\b'.preg_quote($card['year'],'/').'\\b/',$t)){$score+=8;$reasons[]='year match';}
  elseif(($card['year']??'')&&preg_match('/\\b(18|19|20)\\d{2}(?:-\\d{2})?\\b/',$t,$m)&&$m[0]!==$card['year'])return [0,['excluded: wrong year'],'wrong year',[]];

  if(($card['card_number']??'')){
    $compact=str_replace([' ','#'],'',$t);$number=strtolower(str_replace(' ','',$card['card_number']));
    if(str_contains($compact,$number)){$score+=25;$reasons[]='card number match';}
    else {$score-=18;$penalties[]='card number missing';}
  }

  foreach(['brand'=>10,'set'=>12,'category'=>5] as $field=>$weight){
    $v=self::norm($card[$field]??'');if(!$v)continue;
    if(str_contains($t,$v)){$score+=$weight;$reasons[]="$field match";}
    elseif($field==='set'){$score-=5;$penalties[]='set missing';}
  }

  $subject_tokens=$card['subject_tokens']??[];$subject_hits=0;
  foreach($subject_tokens as $token)if(preg_match('/\\b'.preg_quote($token,'/').'\\b/',$t))$subject_hits++;
  if($subject_tokens){
    $coverage=$subject_hits/count($subject_tokens);
    if($coverage<0.5)return [0,['excluded: wrong subject/player'],'wrong subject/player',[]];
    $score+=(int)round(28*$coverage);$reasons[]='subject '.round($coverage*100).'%';
  }

  $variant=strtolower($card['variant']??'');
  if($variant==='unlimited'&&(str_contains($t,'1st edition')||str_contains($t,'first edition')||str_contains($t,'shadowless')))return [0,['excluded: wrong variant'],'wrong variant',[]];
  if($variant==='1st edition'&&!str_contains($t,'1st edition')&&!str_contains($t,'first edition'))return [0,['excluded: missing 1st Edition'],'wrong variant',[]];
  if($variant==='shadowless'&&!str_contains($t,'shadowless'))return [0,['excluded: missing Shadowless'],'wrong variant',[]];
  if($variant==='rookie'){if(str_contains($t,'rookie')||preg_match('/\\brc\\b/',$t)){$score+=6;$reasons[]='rookie match';}else{$score-=4;$penalties[]='rookie not stated';}}

  $parallel=self::norm($card['parallel']??'');
  if($parallel){if(str_contains($t,$parallel)){$score+=10;$reasons[]='parallel match';}else return [0,['excluded: wrong or missing parallel'],'wrong parallel',[]];}
  else{$parallel_terms=['silver','refractor','gold','red','blue','green','purple','orange','pink','black','wave','ice','laser','checkerboard','genesis','downtown','kaboom','hyper'];foreach($parallel_terms as $pt)if(str_contains($t,$pt)){$score-=5;$penalties[]='unspecified parallel';break;}}

  if(($card['language']??'English')!=='English'){$lang=strtolower($card['language']);if(str_contains($t,$lang)){$score+=5;$reasons[]='language match';}else return [0,['excluded: language mismatch'],'language mismatch',[]];}
  elseif(preg_match('/\\b(japanese|korean|chinese|spanish|french|german|italian)\\b/',$t))return [0,['excluded: non-English listing'],'language mismatch',[]];

  $identity_fields=0;foreach(['year','brand','set','subject','card_number','grader','grade','variant','parallel'] as $f)if(!empty($card[$f]))$identity_fields++;
  $score+=min(8,$identity_fields);
  return [max(0,min(100,$score)),$reasons,$excluded,$penalties];
 }
 static function effective_threshold($card){
  $base=(int)get_option('sg_min_match_score',60);
  if(!empty($card['card_number']))return max(55,$base);
  if(!empty($card['subject'])&&!empty($card['grader'])&&!empty($card['grade']))return min($base,52);
  return min($base,48);
 }
 static function percentile($a,$p){$n=count($a);if(!$n)return 0;$i=($n-1)*$p;$lo=(int)floor($i);$hi=(int)ceil($i);return $a[$lo]+($a[$hi]-$a[$lo])*($i-$lo);}
 static function valuation($rows){
  $prices=array_map(fn($x)=>(float)$x['price'],$rows);sort($prices);if(!$prices)return ['low'=>0,'median'=>0,'high'=>0,'confidence'=>0,'rows'=>[]];
  $q1=self::percentile($prices,.25);$q3=self::percentile($prices,.75);$iqr=$q3-$q1;$min=max(0,$q1-1.5*$iqr);$max=$q3+1.5*$iqr;
  $clean=array_values(array_filter($rows,fn($x)=>$x['price']>=$min&&$x['price']<=$max));if(count($clean)>=3)$rows=$clean;
  $prices=array_map(fn($x)=>(float)$x['price'],$rows);sort($prices);$n=count($prices);$median=self::percentile($prices,.5);$mean=$n?array_sum($prices)/$n:0;$variance=0;foreach($prices as $p)$variance+=($p-$mean)**2;$cv=$mean>0?sqrt($variance/max(1,$n))/$mean:1;$avgScore=$n?array_sum(array_column($rows,'score'))/$n:0;$confidence=(int)round(min(98,max(0,$avgScore*.62+min(25,$n*2)-min(25,$cv*50))));
  return ['low'=>round(self::percentile($prices,.25),2),'median'=>round($median,2),'high'=>round(self::percentile($prices,.75),2),'confidence'=>$confidence,'rows'=>$rows];
 }
 static function search(WP_REST_Request $req){
  $q=self::request_query($req);if(strlen($q)<3)return new WP_Error('query','Enter at least 3 characters.',['status'=>400]);
  $key='sg_search_v21_'.md5(strtolower($q));if(!filter_var($req->get_param('refresh'),FILTER_VALIDATE_BOOLEAN)&&($v=get_transient($key)))return $v;
  $token=self::token();if(is_wp_error($token))return $token;$body=self::ebay_request($q,$token,200);if(is_wp_error($body))return $body;
  $card=self::parse_card($q);$accepted=[];$excluded=[];$threshold=self::effective_threshold($card);
  foreach(($body['itemSummaries']??[]) as $i){
    $price=(float)($i['price']['value']??0);if($price<=0)continue;
    [$score,$reasons,$why,$penalties]=self::score_listing($i['title']??'',$card,$q);
    $row=['title'=>sanitize_text_field($i['title']??''),'price'=>$price,'currency'=>$i['price']['currency']??'USD','url'=>esc_url_raw($i['itemWebUrl']??''),'image'=>esc_url_raw($i['image']['imageUrl']??''),'score'=>$score,'condition'=>sanitize_text_field($i['condition']??''),'reasons'=>$reasons,'penalties'=>$penalties,'buying_options'=>$i['buyingOptions']??[],'item_id'=>sanitize_text_field($i['itemId']??'')];
    if($score>=$threshold)$accepted[]=$row;else{$row['excluded_reason']=$why?:'match score below threshold';$excluded[]=$row;}
  }
  usort($accepted,fn($a,$b)=>$b['score']<=>$a['score']);$val=self::valuation($accepted);$qualified=$val['rows'];$accepted=array_slice($qualified,0,40);
  $excluded_summary=array_count_values(array_map(fn($x)=>$x['excluded_reason'],$excluded));
  $diagnostics=['parser'=>$card,'effective_threshold'=>$threshold,'top_excluded'=>array_slice($excluded,0,10),'recommendation'=>'For tighter results, include card number and parallel/variant.'];
  $out=['success'=>true,'engine_version'=>'2.1','query'=>$q,'card'=>$card,'valuation'=>['low'=>$val['low'],'median'=>$val['median'],'high'=>$val['high'],'currency'=>'USD','confidence'=>$val['confidence']],'market'=>['estimate_type'=>'active_listing','accepted_comparables'=>count($qualified),'displayed_comparables'=>count($accepted),'excluded_results'=>count($excluded),'source_results'=>count($body['itemSummaries']??[]),'last_updated'=>gmdate('c'),'match_threshold'=>$threshold],'listings'=>$accepted,'excluded_summary'=>$excluded_summary,'diagnostics'=>$diagnostics,'notice'=>'Estimate based on current eBay asking prices, not completed sales, accepted Best Offers, or an appraisal.'];
  global $wpdb;$t=self::tables();$wpdb->insert($t['snapshots'],['card_key'=>$card['card_key'],'query_hash'=>hash('sha256',strtolower($q)),'query_text'=>$q,'estimate_type'=>'active_listing','median_price'=>$val['median'],'low_price'=>$val['low'],'high_price'=>$val['high'],'listing_count'=>count($qualified),'excluded_count'=>count($excluded),'confidence'=>$val['confidence'],'payload'=>wp_json_encode(['engine_version'=>'2.1','card'=>$card,'listings'=>$accepted,'excluded_summary'=>$excluded_summary]),'created_at'=>current_time('mysql')]);
  set_transient($key,$out,max(1,(int)get_option('sg_search_cache_minutes',15))*MINUTE_IN_SECONDS);return $out;
 }
 static function parse_endpoint(WP_REST_Request $r){$q=self::request_query($r);if(strlen($q)<3)return new WP_Error('query','Enter at least 3 characters.',['status'=>400]);$card=self::parse_card($q);return ['success'=>true,'engine_version'=>'2.1','query'=>$q,'card'=>$card,'effective_threshold'=>self::effective_threshold($card)];}
 static function history(WP_REST_Request $r){global $wpdb;$t=self::tables();$q=trim((string)$r->get_param('q'));$key=trim((string)$r->get_param('card_key'));$limit=max(1,min(365,(int)($r->get_param('limit')?:90)));if(!$q&&!$key)return new WP_Error('identifier','Provide q or card_key.',['status'=>400]);if($key)$sql=$wpdb->prepare("SELECT median_price,low_price,high_price,confidence,listing_count,created_at FROM {$t['snapshots']} WHERE card_key=%s ORDER BY created_at ASC LIMIT %d",$key,$limit);else $sql=$wpdb->prepare("SELECT median_price,low_price,high_price,confidence,listing_count,created_at FROM {$t['snapshots']} WHERE query_hash=%s ORDER BY created_at ASC LIMIT %d",hash('sha256',strtolower($q)),$limit);return ['history'=>$wpdb->get_results($sql,ARRAY_A)];}

 static function portfolio_get(){global $wpdb;$t=self::tables();$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t['portfolio']} WHERE user_id=%d ORDER BY updated_at DESC",get_current_user_id()),ARRAY_A);$total=0;foreach($rows as $x)$total+=(float)$x['market_value']*max(1,(int)$x['quantity']);return ['items'=>$rows,'summary'=>['count'=>count($rows),'market_value'=>round($total,2)]];}
 static function portfolio_payload($p,$existing=[]){$name=sanitize_text_field($p['card_name']??$p['name']??($existing['card_name']??''));$card=self::parse_card(trim(($p['year']??'').' '.($p['category']??'').' '.($p['card_set']??$p['set']??'').' '.$name.' '.($p['card_number']??'').' '.($p['variant']??'').' '.($p['grader']??'').' '.($p['grade']??'')));return ['card_key'=>sanitize_text_field($p['card_key']??$card['card_key']),'card_name'=>$name,'card_set'=>sanitize_text_field($p['card_set']??$p['set']??($existing['card_set']??'')),'card_number'=>sanitize_text_field($p['card_number']??($existing['card_number']??'')),'year'=>sanitize_text_field($p['year']??($existing['year']??'')),'category'=>sanitize_text_field($p['category']??($existing['category']??'')),'variant'=>sanitize_text_field($p['variant']??($existing['variant']??'')),'language'=>sanitize_text_field($p['language']??($existing['language']??'English')),'grader'=>sanitize_text_field($p['grader']??($existing['grader']??'')),'grade'=>sanitize_text_field($p['grade']??($existing['grade']??'')),'cert_number'=>sanitize_text_field($p['cert_number']??$p['cert']??($existing['cert_number']??'')),'quantity'=>max(1,(int)($p['quantity']??($existing['quantity']??1))),'cost'=>(float)($p['cost']??($existing['cost']??0)),'market_value'=>(float)($p['market_value']??$p['value']??($existing['market_value']??0)),'notes'=>sanitize_textarea_field($p['notes']??($existing['notes']??''))];}
 static function portfolio_add(WP_REST_Request $r){global $wpdb;$t=self::tables();$p=$r->get_json_params();$data=self::portfolio_payload($p);if(!$data['card_name'])return new WP_Error('name','Card name is required.',['status'=>400]);$now=current_time('mysql');$data=['user_id'=>get_current_user_id()]+$data+['created_at'=>$now,'updated_at'=>$now];$wpdb->insert($t['portfolio'],$data);return new WP_REST_Response(['id'=>$wpdb->insert_id]+$data,201);}
 static function portfolio_update(WP_REST_Request $r){global $wpdb;$t=self::tables();$id=(int)$r['id'];$old=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$t['portfolio']} WHERE id=%d AND user_id=%d",$id,get_current_user_id()),ARRAY_A);if(!$old)return new WP_Error('not_found','Card not found.',['status'=>404]);$data=self::portfolio_payload($r->get_json_params(),$old);$data['updated_at']=current_time('mysql');$wpdb->update($t['portfolio'],$data,['id'=>$id,'user_id'=>get_current_user_id()]);return ['id'=>$id]+$data;}
 static function portfolio_delete(WP_REST_Request $r){global $wpdb;$t=self::tables();$deleted=$wpdb->delete($t['portfolio'],['id'=>(int)$r['id'],'user_id'=>get_current_user_id()]);return ['deleted'=>(bool)$deleted];}
 static function feedback(WP_REST_Request $r){global $wpdb;$t=self::tables();$p=$r->get_json_params();$m=sanitize_textarea_field($p['message']??'');if(!$m)return new WP_Error('message','Feedback message is required.',['status'=>400]);$wpdb->insert($t['feedback'],['user_id'=>get_current_user_id(),'email'=>sanitize_email($p['email']??''),'type'=>sanitize_text_field($p['type']??'general'),'message'=>$m,'page_url'=>esc_url_raw($p['page_url']??''),'created_at'=>current_time('mysql')]);return ['saved'=>true];}
}
SlabGrad_Core::init();
